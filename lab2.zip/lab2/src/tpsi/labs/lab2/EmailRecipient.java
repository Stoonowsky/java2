package tpsi.labs.lab2;

public interface EmailRecipient {

    String getEmailAddress();
}
